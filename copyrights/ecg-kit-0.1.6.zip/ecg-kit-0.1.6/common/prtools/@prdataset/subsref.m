%SUBSREF Subscripted reference. Dataset overload
%
% 
% $Id: subsref.m,v 1.20 2010/06/01 08:47:05 duin Exp $

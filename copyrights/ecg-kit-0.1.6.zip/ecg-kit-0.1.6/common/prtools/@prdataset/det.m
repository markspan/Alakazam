%DET Dataset overload
%
%Computes determinant of data, a.data must be square 

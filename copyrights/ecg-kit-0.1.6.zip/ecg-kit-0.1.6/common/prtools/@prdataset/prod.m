%PROD Product of elements. Dataset overload

%GETVERSION Get PRTools version and date of dataset
%
%   [VERSION,DATE] = GETVERSION(A)
%
% INPUT
%   A        Dataset
% 
% OUTPUT
%   VERSION  PRTools version with which A was created
%   DATE     Date of creation of A

%DISP Display mapping
%
%	  DISP(W)
% 
% INPUT 
%   W   Mapping
%
% DESCRIPTION
% Display mapping W and its data field.

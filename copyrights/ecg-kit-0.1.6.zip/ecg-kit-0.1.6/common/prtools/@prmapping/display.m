%DISPLAY Display mapping information

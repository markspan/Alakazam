%SUBSASGN Datafile overload

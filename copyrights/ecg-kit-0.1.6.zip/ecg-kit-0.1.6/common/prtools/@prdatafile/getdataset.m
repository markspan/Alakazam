%GETDATASET Get dataset of datafile

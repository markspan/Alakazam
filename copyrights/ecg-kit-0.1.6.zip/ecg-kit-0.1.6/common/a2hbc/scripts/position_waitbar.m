if( bHaveUserInterface )
    set( progress_struct.handle, 'units', 'normalized');
    set( progress_struct.handle, 'position', [ 0.26 0.303 0.217 0.094 ]);
end

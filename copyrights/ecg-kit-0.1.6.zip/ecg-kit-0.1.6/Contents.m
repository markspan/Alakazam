% ECGKIT
% Version 0.1 01-Oct-2014
% Files

%   InstallECGkit   - Installation script of ECGkit
%   UnInstallECGkit - Uninstallation script of ECGkit
%   ECGkit_examples - Example of how to use the ECGkit
